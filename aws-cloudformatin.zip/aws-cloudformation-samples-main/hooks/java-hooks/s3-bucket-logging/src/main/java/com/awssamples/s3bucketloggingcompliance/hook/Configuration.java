package com.awssamples.s3bucketloggingcompliance.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-s3bucketloggingcompliance-hook.json");
    }
}
