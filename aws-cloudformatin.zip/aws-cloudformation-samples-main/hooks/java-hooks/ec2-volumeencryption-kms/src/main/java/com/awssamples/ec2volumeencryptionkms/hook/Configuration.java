package com.awssamples.ec2volumeencryptionkms.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-s3bucketloggingcompliance-hook.json");
    }
}
