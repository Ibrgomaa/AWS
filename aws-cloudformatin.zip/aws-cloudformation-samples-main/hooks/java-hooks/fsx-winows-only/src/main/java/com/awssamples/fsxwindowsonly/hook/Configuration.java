package com.awssamples.fsxwindowsonly.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-fsxwindowsonly-hook.json");
    }
}
