package com.awssamples.efsencrypt.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-efsencrypt-hook.json");
    }
}
