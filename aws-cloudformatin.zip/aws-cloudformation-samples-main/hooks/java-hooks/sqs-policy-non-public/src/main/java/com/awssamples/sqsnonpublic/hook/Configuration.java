package com.awssamples.sqsnonpublic.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-sqsnonpublic-hook.json");
    }
}
