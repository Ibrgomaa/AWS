package com.awssamples.noip6.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-noip6-hook.json");
    }
}
