package com.awssamples.sqspolicyencryption.hook;

class Configuration extends BaseHookConfiguration {

    public Configuration() {
        super("awssamples-sqspolicyencryption-hook.json");
    }
}
